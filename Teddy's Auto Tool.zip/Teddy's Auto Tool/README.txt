Teddy's Auto Toolkit — Portable EXE Builder
==========================================
What this gives you:
  • A one-click builder that creates a portable Windows EXE.
  • Result: a folder `dist\TeddysAutoToolkit\TeddysAutoToolkit.exe` you can double‑click to run.
  • No installers or pip on the target machine — just run the EXE after it's built once on your PC.

How to use:
  1) Extract this zip somewhere like Desktop.
  2) Open the folder and double‑click **Build_EXE.bat**.
  3) When it finishes, open `dist\TeddysAutoToolkit\TeddysAutoToolkit.exe` (a shortcut file is created too).

Notes:
  • The build step happens only once on your machine and requires internet to fetch PyInstaller.
  • The final EXE is "onedir" portable style: it sits with its needed DLLs in the same folder.
  • If Windows Smartscreen warns, click "More info" → "Run anyway" (unsigned but safe).

Rebuild / Clean:
  • Run **Clean.bat** to delete build artifacts (dist, build, .spec, .venv).
