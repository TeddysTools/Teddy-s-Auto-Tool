#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
File: Toolkit.py
Name: Teddy's Auto Toolkit

Target Python: 3.12.10
Optional deps (tray + icons):  pip install pystray pillow
Core dep:                      pip install pynput

This build:
- Kill switch hotkey (instant); single "toggle selected" hotkey.
- Tray with Open / Stop All / Quit; toggleable in UI.
- Saves window size, theme, prefs.
- Clear buttons next to **Total clicks** and **Longest hold**.
- **Animated text bear** with wink/blink/ears/wave; long-press opens link.
- **Windows taskbar icon** matches tray bear (creates .ico at runtime).
- HUD tags near cursor when Auto Clicker / Hold / Typer are active.
- NEW: Hotkey capture supports combos of up to **two keys** (e.g., ctrl+1, ctrl+F1).
- NEW: Header label shows version **“Teddy’s Auto Toolkit v1.0”** (window title unchanged).
- Tray menu trimmed to **Open / Stop All / Quit**.
"""

from __future__ import annotations

import json
import os
import random
import sys
import tempfile
import threading
import time
import webbrowser
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Optional, Set, Tuple, Union
from urllib.parse import quote

import tkinter as tk

# ---- Optional Windows AUMID (helps taskbar use our icon instead of python) ----
try:
    import ctypes  # noqa: F401
    _HAS_CTYPES = True
except Exception:
    _HAS_CTYPES = False

# External deps (core)
try:
    from pynput import keyboard as pkbd
    from pynput import mouse as pmouse
except Exception as e:
    print("pynput is required. Install with: pip install pynput")
    print(e)
    sys.exit(1)

APP_NAME = "Teddy's Auto Toolkit"
APP_NAME_VERSION = "Teddy's Auto Toolkit v1.0"
STATS_PATH = Path.home() / ".teddys_auto_toolkit.json"
CONTACT_EMAIL = "TheTeddysTools@proton.me"
BEAR_DONATE_URL = "https://www.americanbear.org/donate/?srsltid=AfmBOopW7Jo5ng9Q54vpqUfFmNQFzFQ-bZV-qVALBS_XzEUmOaxWa5uZ"

# ----------------------------- THEME DEFINITIONS -----------------------------
THEMES: Dict[str, Dict[str, str]] = {
    "normal": {"bg": "#F2F2F2", "fg": "#111111", "accent": "#3B82F6", "panel": "#FFFFFF", "muted": "#6B7280"},
    "dark":   {"bg": "#0F172A", "fg": "#E5E7EB", "accent": "#22D3EE", "panel": "#EDEEF0", "muted": "#94A3B8"},
    "pink":   {"bg": "#FFF1F5", "fg": "#3B0764", "accent": "#EC4899", "panel": "#FFFFFF", "muted": "#9D174D"},
    "red":    {"bg": "#000000", "fg": "#FFFFFF", "accent": "#EF4444", "panel": "#FFFFFF", "muted": "#9CA3AF"},
    "bear":   {"bg": "#1F1B16", "fg": "#F5F1E6", "accent": "#D4A373", "panel": "#F5F1E6", "muted": "#8B7E69"},
}

# ------------------------------ KEY CONVERSIONS ------------------------------
SpecialKey = pkbd.Key
KeyLike = Union[SpecialKey, pkbd.KeyCode]

SPECIAL_KEY_NAMES: Dict[str, SpecialKey] = {
    "shift": SpecialKey.shift,   "shift_l": SpecialKey.shift_l,   "shift_r": SpecialKey.shift_r,
    "ctrl":  SpecialKey.ctrl,    "ctrl_l":  SpecialKey.ctrl_l,    "ctrl_r":  SpecialKey.ctrl_r,
    "alt":   SpecialKey.alt,     "alt_l":   SpecialKey.alt_l,     "alt_r":   SpecialKey.alt_r,
    "caps_lock": SpecialKey.caps_lock, "tab": SpecialKey.tab, "esc": SpecialKey.esc,
    "space": SpecialKey.space, "enter": SpecialKey.enter, "backspace": SpecialKey.backspace,
    "delete": SpecialKey.delete, "home": SpecialKey.home, "end": SpecialKey.end,
    "page_up": SpecialKey.page_up, "page_down": SpecialKey.page_down,
    "up": SpecialKey.up, "down": SpecialKey.down, "left": SpecialKey.left, "right": SpecialKey.right,
}
for i in range(1, 25):
    SPECIAL_KEY_NAMES[f"f{i}"] = getattr(SpecialKey, f"f{i}")

# Normalize left/right variants to a single name for chords
NORM_MAP = {
    "shift_l": "shift", "shift_r": "shift",
    "ctrl_l": "ctrl", "ctrl_r": "ctrl",
    "alt_l": "alt", "alt_r": "alt",
}

def key_to_str(key: KeyLike) -> str:
    if isinstance(key, pkbd.KeyCode):
        return key.char.lower() if key.char else ""
    if isinstance(key, pkbd.Key):
        return key.name
    return str(key)

def normalize_key_name(name: str) -> str:
    if not name:
        return ""
    name = name.lower().strip()
    return NORM_MAP.get(name, name)

def canonical_combo(keys: Set[str]) -> str:
    """Canonical order: modifiers first (ctrl, shift, alt), then others."""
    order = {"ctrl": 0, "shift": 1, "alt": 2}
    parts = sorted(keys, key=lambda s: (order.get(s, 99), s))
    return "+".join(parts)

# ------------------------------- DATA CLASSES --------------------------------
@dataclass
class Stats:
    total_clicks: int = 0
    longest_hold_seconds: float = 0.0
    selected_theme: str = "normal"
    window_geometry: Optional[str] = None
    prefs: Optional[dict] = None  # hotkeys + UI state

    @classmethod
    def load(cls) -> "Stats":
        try:
            data = json.loads(STATS_PATH.read_text(encoding="utf-8"))
            return cls(**{**cls().__dict__, **data})
        except Exception:
            return cls()

    def save(self) -> None:
        try:
            STATS_PATH.write_text(json.dumps(self.__dict__, indent=2), encoding="utf-8")
        except Exception:
            pass

# ------------------------------- APP CONTROLLER -------------------------------
class TeddyToolkit:
    def __init__(self) -> None:
        # Set Windows AppUserModelID early so taskbar uses our icon
        if _HAS_CTYPES and sys.platform.startswith("win"):
            try:
                ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("Teddys.Auto.Toolkit")
            except Exception:
                pass

        self.stats = Stats.load()
        if self.stats.prefs is None:
            self.stats.prefs = {}

        self.mctl = pmouse.Controller()
        self.kctl = pkbd.Controller()
        self.MOUSE_BUTTONS = {"Left": pmouse.Button.left, "Middle": pmouse.Button.middle, "Right": pmouse.Button.right}

        # Runtime state
        self.autoclick_running = threading.Event()
        self.mouse_hold_running = threading.Event()
        self.typer_running = threading.Event()
        self.active_actions = 0
        self.modifiers_pressed: Set[SpecialKey] = set()
        self.caps_flipped = False
        self.session_clicks = 0
        self.autoclick_thread: Optional[threading.Thread] = None
        self.mouse_hold_thread: Optional[threading.Thread] = None
        self.typer_thread: Optional[threading.Thread] = None
        self.hold_start_time: Optional[float] = None
        self.current_hold_elapsed: float = 0.0

        # HUD tag windows
        self._hud: Dict[str, tk.Toplevel] = {}
        self._hud_job: Optional[str] = None

        # Hotkeys (may be single or two-key combos)
        self.hotkeys: Dict[str, Optional[str]] = {
            "toggle_action": self.stats.prefs.get("toggle_action"),
            "kill_switch": self.stats.prefs.get("kill_switch"),
        }
        self.hotkey_debounce_at = 0.0
        self._active_combo: Optional[str] = None
        self._pressed_keys: Set[str] = set()

        # Capture state for binding combos
        self.capturing_for: Optional[str] = None
        self._capture_keys: Set[str] = set()
        self._capture_finalize_job: Optional[str] = None
        self._hotkey_popup: Optional[tk.Toplevel] = None

        # Build UI then start listener
        self._build_ui()
        self.klistener = pkbd.Listener(on_press=self._on_key_press, on_release=self._on_key_release)
        self.klistener.daemon = True
        self.klistener.start()

    # ---------------------------- GUI CONSTRUCTION ---------------------------
    def _build_ui(self) -> None:
        self.root = tk.Tk()
        self.root.title(APP_NAME)
        self.root.update_idletasks()
        if self.stats.window_geometry:
            self.root.geometry(self.stats.window_geometry)
        else:
            sw, sh = self.root.winfo_screenwidth(), self.root.winfo_screenheight()
            w = min(int(sw * 0.9), 1920)
            h = min(int(sh * 0.9), 1280)
            self.root.geometry(f"{w}x{h}")
        self.root.minsize(1000, 700)
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)

        # Apply our bear icon to Taskbar/Title/Alt+Tab (Windows) if possible
        self._install_taskbar_icon()

        # Fonts
        self.text_font = ("Segoe UI", 10, "bold")
        self.header_font = ("Segoe UI", 12, "bold")
        self.title_font = ("Segoe UI", 18, "bold")

        # Theme selector (persisted)
        self.theme_var = tk.StringVar(self.root, value=self.stats.selected_theme or "normal")

        topbar = tk.Frame(self.root, bd=0); topbar.pack(fill=tk.X, padx=14, pady=(12, 6))
        # Show version only here
        tk.Label(topbar, text=APP_NAME_VERSION, font=self.title_font).pack(side=tk.LEFT)

        tk.Label(topbar, text="Theme:", font=self.text_font).pack(side=tk.LEFT, padx=(16, 6))
        opt = tk.OptionMenu(topbar, self.theme_var, *THEMES.keys(), command=self._apply_theme)
        opt.pack(side=tk.LEFT)

        # Right/top controls: contact + watermark
        right_top = tk.Frame(topbar, bd=0); right_top.pack(side=tk.RIGHT)
        self.watermark = tk.Label(right_top, text="Teddy's Tools", font=self.text_font)
        self.watermark.pack(side=tk.RIGHT)
        contact_col = tk.Frame(right_top, bd=0); contact_col.pack(side=tk.RIGHT, padx=(10, 0))
        tk.Button(contact_col, text="Contact Teddy", command=self.copy_email_to_clipboard).pack(anchor="e")
        tk.Button(contact_col, text="open email app", command=self.open_email_app).pack(anchor="e")

        # Global Hotkey Panel
        hkpanel = tk.Frame(self.root, bd=0); hkpanel.pack(fill=tk.X, padx=14, pady=(0, 8))
        self.toggle_target = tk.StringVar(self.root, value=self.stats.prefs.get("toggle_target", "auto_click"))
        tk.Label(hkpanel, text="Hotkey controls:", font=self.text_font).pack(side=tk.LEFT)
        self.hotkey_toggle_rbs = []
        for label, val in (("Auto Click", "auto_click"), ("Hold Click", "hold_click"), ("Auto Typer", "auto_typer")):
            rb = tk.Radiobutton(hkpanel, text=label, value=val, variable=self.toggle_target, indicatoron=False, width=10)
            rb.pack(side=tk.LEFT, padx=4)
            self.hotkey_toggle_rbs.append(rb)

        self.global_hotkey_lbl = tk.Label(
            hkpanel, text=f"Hotkey: {self.hotkeys.get('toggle_action') or '(none)'}", font=self.text_font
        )
        self.global_hotkey_lbl.pack(side=tk.LEFT, padx=(16, 6))
        tk.Button(hkpanel, text="Bind key", command=lambda: self.capture_hotkey("toggle_action")).pack(side=tk.LEFT)
        tk.Button(hkpanel, text="Clear", command=lambda: self._set_hotkey("toggle_action", None)).pack(side=tk.LEFT, padx=(6, 0))

        # Kill switch block (instant only)
        killcol = tk.Frame(hkpanel, bd=0); killcol.pack(side=tk.LEFT, padx=(16, 0))
        row_top = tk.Frame(killcol, bd=0); row_top.pack(anchor="w")
        self.kill_hotkey_lbl = tk.Label(
            row_top, text=f"Kill switch: {self.hotkeys.get('kill_switch') or '(none)'}", font=self.text_font
        ); self.kill_hotkey_lbl.pack(side=tk.LEFT)
        tk.Button(row_top, text="Bind", command=lambda: self.capture_hotkey("kill_switch")).pack(side=tk.LEFT, padx=(6, 0))
        tk.Button(row_top, text="Clear", command=lambda: self._set_hotkey("kill_switch", None)).pack(side=tk.LEFT, padx=(6, 0))

        # Tray toggle
        traycol = tk.Frame(hkpanel, bd=0); traycol.pack(side=tk.LEFT, padx=(16, 0))
        self.use_tray_var = tk.BooleanVar(self.root, value=bool(self.stats.prefs.get("use_tray", True)))
        tk.Checkbutton(traycol, text="Use system tray", variable=self.use_tray_var).pack(side=tk.LEFT)
        self.use_tray_var.trace_add('write', lambda *a: self._on_toggle_tray_pref())

        # Main area (grid)
        panels = tk.Frame(self.root, bd=0)
        panels.pack(fill=tk.BOTH, expand=True, padx=14, pady=10)
        panels.grid_columnconfigure(0, weight=1, uniform="col")
        panels.grid_columnconfigure(1, weight=1, uniform="col")

        # Auto Clicker
        ac = self._panel(panels, "Auto Clicker"); ac.grid(row=0, column=0, sticky="nwe", padx=(0, 6))
        self.ac_button_var = tk.StringVar(self.root, value=self.stats.prefs.get("ac_button", "Left"))
        self.ac_button_rbs = []
        row1 = tk.Frame(ac); row1.pack(fill=tk.X, pady=(6, 2))
        tk.Label(row1, text="Button:", font=self.text_font).pack(side=tk.LEFT)
        for name in ("Left", "Middle", "Right"):
            rb = tk.Radiobutton(row1, text=name, value=name, variable=self.ac_button_var, indicatoron=False, width=7)
            rb.pack(side=tk.LEFT, padx=4)
            self.ac_button_rbs.append(rb)
        row2 = tk.Frame(ac); row2.pack(fill=tk.X, pady=(6, 2))
        tk.Label(row2, text="Clicks / sec:", font=self.text_font).pack(side=tk.LEFT)
        self.cps_var = tk.IntVar(self.root, value=self.stats.prefs.get("cps", 10))
        tk.Spinbox(row2, from_=1, to=100, textvariable=self.cps_var, width=6).pack(side=tk.LEFT, padx=(6, 12))
        self.ac_toggle_btn = tk.Button(row2, text="Start", width=10, command=self.toggle_autoclick); self.ac_toggle_btn.pack(side=tk.LEFT)
        row3 = tk.Frame(ac); row3.pack(fill=tk.X, pady=(6, 2))
        self.session_clicks_var = tk.StringVar(self.root, value="Session clicks: 0")
        self.total_clicks_var = tk.StringVar(self.root, value=f"Total clicks: {self.stats.total_clicks}")
        tk.Label(row3, textvariable=self.session_clicks_var, font=self.text_font).pack(side=tk.LEFT)
        tk.Label(row3, textvariable=self.total_clicks_var, font=self.text_font, padx=14).pack(side=tk.LEFT)
        tk.Button(row3, text="Clear", width=7, command=self._clear_total_clicks).pack(side=tk.LEFT, padx=(4, 0))  # NEW

        # Hold Click
        hc = self._panel(panels, "Hold Click"); hc.grid(row=0, column=1, sticky="nwe", padx=(6, 0))
        self.hc_button_var = tk.StringVar(self.root, value=self.stats.prefs.get("hc_button", "Left"))
        self.hc_button_rbs = []
        hrow1 = tk.Frame(hc); hrow1.pack(fill=tk.X, pady=(6, 2))
        tk.Label(hrow1, text="Button:", font=self.text_font).pack(side=tk.LEFT)
        for name in ("Left", "Middle", "Right"):
            rb = tk.Radiobutton(hrow1, text=name, value=name, variable=self.hc_button_var, indicatoron=False, width=7)
            rb.pack(side=tk.LEFT, padx=4)
            self.hc_button_rbs.append(rb)
        hrow2 = tk.Frame(hc); hrow2.pack(fill=tk.X, pady=(6, 2))
        self.hc_toggle_btn = tk.Button(hrow2, text="Hold", width=10, command=self.toggle_mouse_hold); self.hc_toggle_btn.pack(side=tk.LEFT)
        hrow3 = tk.Frame(hc); hrow3.pack(fill=tk.X, pady=(6, 2))
        self.hold_elapsed_var = tk.StringVar(self.root, value="Hold elapsed: 0.0s")
        self.longest_hold_var = tk.StringVar(self.root, value=f"Longest hold: {self.stats.longest_hold_seconds:.1f}s")
        tk.Label(hrow3, textvariable=self.hold_elapsed_var, font=self.text_font).pack(side=tk.LEFT)
        tk.Label(hrow3, textvariable=self.longest_hold_var, font=self.text_font, padx=14).pack(side=tk.LEFT)
        tk.Button(hrow3, text="Clear", width=7, command=self._clear_longest_hold).pack(side=tk.LEFT, padx=(4, 0))  # NEW

        # Modifiers (right column)
        mods = self._panel(panels, "Hold Modifiers During Actions"); mods.grid(row=1, column=1, sticky="nwe", padx=(6, 0), pady=(8, 0))
        self.mod_vars: Dict[str, tk.BooleanVar] = {}
        grid = tk.Frame(mods); grid.pack(fill=tk.X, pady=(4, 2))
        mod_keys = [("Left Shift", "shift_l"), ("Right Shift", "shift_r"), ("Left Ctrl", "ctrl_l"), ("Right Ctrl", "ctrl_r"),
                    ("Left Alt", "alt_l"), ("Right Alt", "alt_r"), ("CapsLock", "caps_lock"), ("Tab", "tab")]
        for idx, (label, name) in enumerate(mod_keys):
            var = tk.BooleanVar(self.root, value=bool(self.stats.prefs.get("mods", {}).get(name, False)))
            self.mod_vars[name] = var
            tk.Checkbutton(grid, text=label, variable=var).grid(row=idx // 2, column=idx % 2, sticky="w", padx=6, pady=2)

        # Auto Typer (bottom-right)
        at = self._panel(panels, "Auto Typer"); at.grid(row=2, column=1, sticky="nwe", padx=(6, 0), pady=(8, 0))
        trow1 = tk.Frame(at); trow1.pack(fill=tk.X, pady=(6, 2))
        tk.Label(trow1, text="Text:", font=self.text_font).pack(side=tk.LEFT)
        self.typer_text = tk.Entry(trow1, width=28)
        self.typer_text.insert(0, self.stats.prefs.get("typer_text", "Hello from Teddy!")); self.typer_text.pack(side=tk.LEFT, padx=(6, 12))
        tk.Label(trow1, text="Interval (s):", font=self.text_font).pack(side=tk.LEFT)
        self.typer_delay = tk.DoubleVar(self.root, value=float(self.stats.prefs.get("typer_delay", 1.0)))
        tk.Spinbox(trow1, from_=0.05, to=60.0, increment=0.05, textvariable=self.typer_delay, width=6).pack(side=tk.LEFT, padx=(6, 12))
        self.typer_enter_var = tk.BooleanVar(self.root, value=bool(self.stats.prefs.get("typer_enter", False)))
        tk.Checkbutton(trow1, text="Press Enter after each", variable=self.typer_enter_var).pack(side=tk.LEFT)
        trow2 = tk.Frame(at); trow2.pack(fill=tk.X, pady=(6, 2))
        self.typer_toggle_btn = tk.Button(trow2, text="Start", width=10, command=self.toggle_typer); self.typer_toggle_btn.pack(side=tk.LEFT)

        # Bottom-right **animated text** bear
        self._setup_corner_bear_text()

        # Persist + refresh styling on changes
        self.toggle_target.trace_add('write', lambda *args: (self._persist_pref("toggle_target", self.toggle_target.get()),
                                                             self._refresh_toggle_groups()))
        self.ac_button_var.trace_add('write', lambda *args: (self._persist_pref("ac_button", self.ac_button_var.get()),
                                                             self._refresh_toggle_groups()))
        self.hc_button_var.trace_add('write', lambda *args: (self._persist_pref("hc_button", self.hc_button_var.get()),
                                                             self._refresh_toggle_groups()))
        for key, var in self.mod_vars.items():
            var.trace_add('write', lambda *a, k=key, v=var: self._persist_mod(k, v.get()))

        self._apply_theme(self.theme_var.get())
        if self.use_tray_var.get():
            self._ensure_tray()

        self._ui_tick()

    def _panel(self, parent: tk.Widget, title: str) -> tk.Frame:
        wrapper = tk.Frame(parent, bd=0)
        tk.Label(wrapper, text=title, font=self.header_font).pack(anchor="w")
        body = tk.Frame(wrapper, bd=0, highlightthickness=1)
        body.pack(fill=tk.X, expand=False, padx=(0, 0), pady=(4, 8))
        wrapper.body = body  # type: ignore[attr-defined]
        return wrapper

    # --------------------- Taskbar / Window icon installation ------------------
    def _build_bear_pil(self, size=64):
        try:
            from PIL import Image, ImageDraw  # type: ignore
        except Exception:
            return None
        img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
        d = ImageDraw.Draw(img)
        d.ellipse((8, 10, size-8, size-6), fill=(196, 150, 106, 255))            # face
        ear = int(size * 0.31)
        d.ellipse((2, 0, 2+ear, 0+ear), fill=(150, 110, 80, 255))                # ears
        d.ellipse((size-ear-2, 0, size-2, 0+ear), fill=(150, 110, 80, 255))
        e = int(size*0.09)
        d.ellipse((size*0.38, size*0.44, size*0.38+e, size*0.44+e), fill=(0,0,0,255))
        d.ellipse((size*0.53, size*0.44, size*0.53+e, size*0.44+e), fill=(0,0,0,255))
        d.ellipse((size*0.47, size*0.56, size*0.47+e, size*0.56+e), fill=(0,0,0,255))
        return img

    def _install_taskbar_icon(self) -> None:
        """Create a temporary .ico for Windows taskbar and use the same image for tray."""
        self._bear_ico_path = None
        try:
            from PIL import ImageTk  # type: ignore
            pil = self._build_bear_pil(256)
            if pil is None:
                return
            ico_path = Path(tempfile.gettempdir()) / "teddy_bear_icon.ico"
            pil.save(ico_path, sizes=[(16, 16), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)])
            self._bear_ico_path = str(ico_path)
            try:
                if sys.platform.startswith("win"):
                    self.root.iconbitmap(self._bear_ico_path)
            except Exception:
                pass
            tk_img = ImageTk.PhotoImage(self._build_bear_pil(64))
            self.root.iconphoto(True, tk_img)
            self._tk_icon_photo_ref = tk_img
        except Exception:
            pass

    # --------------------------- WINDOW GEOMETRY & TRAY -------------------------
    def _save_window_geometry(self) -> None:
        try:
            self.stats.window_geometry = self.root.winfo_geometry()
            self.stats.save()
        except Exception:
            pass

    def _on_toggle_tray_pref(self) -> None:
        enabled = bool(self.use_tray_var.get())
        self._persist_pref("use_tray", enabled)
        if enabled:
            self._ensure_tray()
        else:
            self._stop_tray_icon()
            try: self.root.deiconify()
            except Exception: pass

    def _ensure_tray(self) -> None:
        if getattr(self, "_tray_ready", False):
            return
        try:
            import pystray  # type: ignore
            icon_img = self._build_bear_pil(64)
            if icon_img is None:
                self._tray_ready = False
                return
        except Exception:
            self._tray_ready = False
            return

        def on_show(icon, item):   self.root.after(0, self._show_window)
        def on_stop(icon, item):   self.root.after(0, self.panic_stop)
        def on_quit(icon, item):   self.root.after(0, self._quit_from_tray)

        try:
            import pystray  # type: ignore
            self._tray_icon = pystray.Icon(
                APP_NAME, icon_img, APP_NAME,
                menu=pystray.Menu(
                    pystray.MenuItem("Open", on_show, default=True),
                    pystray.MenuItem("Stop All", on_stop),
                    pystray.MenuItem("Quit", on_quit),
                )
            )
            self._tray_thread = threading.Thread(target=self._tray_icon.run, daemon=True)
            self._tray_thread.start()
            self._tray_ready = True
        except Exception:
            self._tray_ready = False

    def _stop_tray_icon(self) -> None:
        try:
            if getattr(self, "_tray_icon", None):
                self._tray_icon.stop()
        except Exception:
            pass
        self._tray_ready = False

    def _show_window(self) -> None:
        try:
            self.root.deiconify(); self.root.after(50, self.root.lift)
        except Exception:
            pass

    def _quit_from_tray(self) -> None:
        self._stop_tray_icon()
        self._really_quit()

    # ------------------------------- THEME LOGIC ------------------------------
    def _apply_theme(self, name: str) -> None:
        if self.stats.selected_theme != name:
            self.stats.selected_theme = name
            self.stats.save()

        theme = THEMES.get(name, THEMES["normal"])
        bg, panel, accent = theme["bg"], theme["panel"], theme["accent"]
        black = "#000000"

        def style_recursive(w: tk.Widget):
            try:
                if isinstance(w, (tk.Frame, tk.Toplevel)):
                    w.configure(bg=bg)
                elif isinstance(w, (tk.Label,)):
                    w.configure(bg=panel, fg=black, font=self.text_font)
                elif isinstance(w, (tk.Radiobutton, tk.Checkbutton)):
                    w.configure(bg=panel, fg=black, activebackground=panel, activeforeground=black, font=self.text_font)
                elif isinstance(w, (tk.Button, tk.Spinbox, tk.Entry, tk.OptionMenu)):
                    btn_bg = panel
                    if name in ("red", "pink") and isinstance(w, tk.Button):
                        btn_bg = accent
                    w.configure(bg=btn_bg, fg=black, activebackground=accent, activeforeground=black, bd=1, highlightthickness=0, font=self.text_font)
                    if isinstance(w, tk.Entry):
                        w.configure(insertbackground=black)
            except tk.TclError:
                pass
            for child in w.winfo_children():
                style_recursive(child)

        for panel_frame in self.root.winfo_children():
            if hasattr(panel_frame, "body"):
                try:
                    panel_frame.body.configure(bg=panel, highlightbackground=accent)
                except Exception:
                    pass

        style_recursive(self.root)
        if hasattr(self, "watermark"): self.watermark.configure(fg=black)
        if hasattr(self, "bear_lbl"): self.bear_lbl.configure(fg=black)
        self._refresh_toggle_groups()

    def _refresh_toggle_groups(self) -> None:
        theme = THEMES.get(self.theme_var.get(), THEMES["normal"])
        panel, accent = theme["panel"], theme["accent"]
        black = "#000000"
        def paint(group, var):
            for rb in group:
                try:
                    if str(rb.cget('value')) == str(var.get()):
                        rb.configure(bg=accent, fg=black, activebackground=accent, activeforeground=black)
                    else:
                        rb.configure(bg=panel, fg=black, activebackground=accent, activeforeground=black)
                except tk.TclError:
                    pass
        paint(self.hotkey_toggle_rbs, self.toggle_target)
        paint(self.ac_button_rbs, self.ac_button_var)
        paint(self.hc_button_rbs, self.hc_button_var)

    # ------------------------------- UI & BEAR --------------------------------
    def _ui_tick(self) -> None:
        if self.hold_start_time is not None:
            self.current_hold_elapsed = max(0.0, time.time() - self.hold_start_time)
            self.hold_elapsed_var.set(f"Hold elapsed: {self.current_hold_elapsed:.1f}s")
        else:
            self.hold_elapsed_var.set("Hold elapsed: 0.0s")
        self.session_clicks_var.set(f"Session clicks: {self.session_clicks}")
        self.total_clicks_var.set(f"Total clicks: {self.stats.total_clicks}")
        self.longest_hold_var.set(f"Longest hold: {self.stats.longest_hold_seconds:.1f}s")
        self.root.after(200, self._ui_tick)

    def _setup_corner_bear_text(self) -> None:
        self.bear_lbl = tk.Label(self.root, text="ʕ•ᴥ•ʔ", font=("Segoe UI", 18, "bold"), bd=0, highlightthickness=0)
        self.bear_lbl.place(relx=1.0, rely=1.0, x=-16, y=-16, anchor="se")
        # Long-press (2s) opens donation link
        self._bear_hold_job: Optional[str] = None
        self.bear_lbl.bind("<ButtonPress-1>", self._on_bear_down)
        self.bear_lbl.bind("<ButtonRelease-1>", self._on_bear_up)
        self.bear_lbl.bind("<Leave>", self._on_bear_up)

        self._bear_anim_mode = "idle"
        self._bear_frame_idx = 0
        self._animate_bear()

    def _on_bear_down(self, _event) -> None:
        if self._bear_hold_job:
            try: self.root.after_cancel(self._bear_hold_job)
            except Exception: pass
        self._bear_hold_job = self.root.after(2000, self._open_bear_link)

    def _on_bear_up(self, _event) -> None:
        if self._bear_hold_job:
            try: self.root.after_cancel(self._bear_hold_job)
            except Exception: pass
            self._bear_hold_job = None

    def _open_bear_link(self) -> None:
        self._bear_hold_job = None
        try:
            webbrowser.open(BEAR_DONATE_URL, new=1)
        except Exception:
            pass

    def _animate_bear(self) -> None:
        idle = ["ʕ•ᴥ•ʔ", "ʕ•ᴥ•ʔ", "ʕ•ᴥ•ʔ", "ʕ•ᴥ•ʔ", "ʕ-ᴥ-ʔ", "ʕ•ᴥ•ʔ"]  # blink
        wink = ["ʕ•ᴥ•ʔ", "ʕ>ᴥ•ʔ", "ʕ>ᴥ•ʔ", "ʕ•ᴥ•ʔ"]
        ears = ["ʕᵒᴥᵒʔ", "ʕᵔᴥᵔʔ", "ʕᵒᴥᵒʔ", "ʕ•ᴥ•ʔ"]
        wave = ["ʕ•ᴥ•ʔ", "ʕ•ᴥ•ʔノ", "ʕ•ᴥ•ʔゞ", "ʕ•ᴥ•ʔノ", "ʕ•ᴥ•ʔ"]
        smile = ["ʕ•ᴥ•ʔ", "ʕ^ᴥ^ʔ", "ʕ^ᴥ^ʔ", "ʕ•ᴥ•ʔ"]

        sets = {"idle": idle, "wink": wink, "ears": ears, "wave": wave, "smile": smile}

        if self._bear_anim_mode == "idle" and random.random() < 0.08:
            self._bear_anim_mode = random.choice(["wink", "ears", "wave", "smile"])
            self._bear_frame_idx = 0

        seq = sets.get(self._bear_anim_mode, idle)
        face = seq[self._bear_frame_idx % len(seq)]
        try:
            self.bear_lbl.configure(text=face)
        except Exception:
            return

        self._bear_frame_idx += 1
        if self._bear_anim_mode != "idle" and self._bear_frame_idx >= len(seq):
            self._bear_anim_mode = "idle"
            self._bear_frame_idx = 0

        delay = 300 if self._bear_anim_mode == "idle" else 180
        self.root.after(delay, self._animate_bear)

    # ------------------------------- HOTKEYS ----------------------------------
    def capture_hotkey(self, action: str) -> None:
        if self.capturing_for:
            return
        self.capturing_for = action
        self._capture_keys.clear()
        self._show_hotkey_popup("Press up to two keys at the same time (Esc to cancel).")

    def _show_hotkey_popup(self, message: str) -> None:
        try:
            if self._hotkey_popup:
                self._hotkey_popup.destroy()
        except Exception:
            pass
        win = tk.Toplevel(self.root)
        win.title(APP_NAME)
        win.transient(self.root)
        frm = tk.Frame(win); frm.pack(fill=tk.BOTH, expand=True, padx=14, pady=12)
        self._hotkey_msg = tk.Label(frm, text=message, justify=tk.LEFT, wraplength=360, font=self.text_font)
        self._hotkey_msg.pack(anchor="w")
        tk.Button(frm, text="OK", command=win.destroy).pack(pady=(10, 0))
        win.update_idletasks()
        x = self.root.winfo_rootx() + self.root.winfo_width()//2 - win.winfo_reqwidth()//2
        y = self.root.winfo_rooty() + self.root.winfo_height()//2 - win.winfo_reqheight()//2
        win.geometry(f"+{max(0,x)}+{max(0,y)}")
        self._hotkey_popup = win

    def _close_hotkey_popup(self) -> None:
        if self._hotkey_popup:
            try:
                self._hotkey_popup.destroy()
            except Exception:
                pass
            self._hotkey_popup = None

    def _update_hotkey_msg(self):
        if getattr(self, "_hotkey_msg", None):
            combo = canonical_combo(self._capture_keys) or "(none)"
            try:
                self._hotkey_msg.configure(text=f"Captured: {combo}\nPress up to two keys (Esc to cancel).")
            except Exception:
                pass

    def _finalize_capture(self):
        if not self.capturing_for:
            return
        combo = canonical_combo(self._capture_keys)
        if combo:
            self._set_hotkey(self.capturing_for, combo)
        self.capturing_for = None
        self._capture_keys.clear()
        self._close_hotkey_popup()

    def _set_hotkey(self, action: str, combo_str: Optional[str]) -> None:
        self.hotkeys[action] = combo_str
        self._persist_pref(action, combo_str)
        if action == "toggle_action":
            self.global_hotkey_lbl.configure(text=f"Hotkey: {combo_str if combo_str else '(none)'}")
        elif action == "kill_switch":
            self.kill_hotkey_lbl.configure(text=f"Kill switch: {combo_str if combo_str else '(none)'}")

    def _on_key_press(self, key: KeyLike) -> None:
        name = normalize_key_name(key_to_str(key))
        if not name:
            return

        now = time.time()
        # Capture mode (build up to two-key combo)
        if self.capturing_for:
            if key == pkbd.Key.esc:
                self.capturing_for = None
                self._close_hotkey_popup()
                return
            if len(self._capture_keys) < 2:
                self._capture_keys.add(name)
                self._update_hotkey_msg()
            # finalize after short settle to allow 2nd key
            if self._capture_finalize_job:
                try: self.root.after_cancel(self._capture_finalize_job)
                except Exception: pass
            self._capture_finalize_job = self.root.after(600, self._finalize_capture)
            return

        # Normal runtime: maintain pressed set
        self._pressed_keys.add(name)
        self._try_trigger_hotkeys(now)

    def _on_key_release(self, key: KeyLike) -> None:
        name = normalize_key_name(key_to_str(key))
        if not name:
            return
        if name in self._pressed_keys:
            self._pressed_keys.remove(name)
        # Reset active combo when keys are lifted
        if not self._pressed_keys:
            self._active_combo = None

    def _try_trigger_hotkeys(self, now: float) -> None:
        # Only consider exact combos of size 1 or 2
        if not (1 <= len(self._pressed_keys) <= 2):
            return
        combo = canonical_combo(self._pressed_keys)
        if not combo or combo == self._active_combo:
            return

        # Debounce
        if now - self.hotkey_debounce_at < 0.15:
            return

        # Check kill first
        if self.hotkeys.get("kill_switch") == combo:
            self.panic_stop()
            self.hotkey_debounce_at = now
            self._active_combo = combo
            return

        # Then toggle
        if self.hotkeys.get("toggle_action") == combo:
            if self.autoclick_running.is_set() or self.mouse_hold_running.is_set() or self.typer_running.is_set():
                if self.autoclick_running.is_set(): self._stop_autoclick()
                if self.mouse_hold_running.is_set(): self._stop_mouse_hold()
                if self.typer_running.is_set(): self._stop_typer()
            else:
                target = self.toggle_target.get()
                if target == "auto_click": self._start_autoclick()
                elif target == "hold_click": self._start_mouse_hold()
                else: self._start_typer()
            self.hotkey_debounce_at = now
            self._active_combo = combo

    # --------------------------- MODIFIER MANAGEMENT --------------------------
    def _selected_modifiers(self) -> Tuple[Set[SpecialKey], bool]:
        mods: Set[SpecialKey] = set()
        for name, var in self.mod_vars.items():
            if var.get() and name in SPECIAL_KEY_NAMES:
                mods.add(SPECIAL_KEY_NAMES[name])
        wants_caps = SPECIAL_KEY_NAMES["caps_lock"] in mods
        if wants_caps and SPECIAL_KEY_NAMES["caps_lock"] in mods:
            mods.remove(SPECIAL_KEY_NAMES["caps_lock"])
        return mods, wants_caps

    def _press_modifiers_if_needed(self) -> None:
        mods, wants_caps = self._selected_modifiers()
        for m in mods:
            if m not in self.modifiers_pressed:
                try:
                    self.kctl.press(m); self.modifiers_pressed.add(m)
                except Exception:
                    pass
        if wants_caps and not self.caps_flipped:
            try:
                self.kctl.press(SPECIAL_KEY_NAMES["caps_lock"]); self.kctl.release(SPECIAL_KEY_NAMES["caps_lock"]); self.caps_flipped = True
            except Exception:
                pass

    def _release_modifiers_if_idle(self) -> None:
        if self.active_actions > 0:
            return
        for m in list(self.modifiers_pressed):
            try: self.kctl.release(m)
            except Exception: pass
            finally: self.modifiers_pressed.discard(m)
        if self.caps_flipped:
            try:
                self.kctl.press(SPECIAL_KEY_NAMES["caps_lock"]); self.kctl.release(SPECIAL_KEY_NAMES["caps_lock"])
            except Exception: pass
            self.caps_flipped = False

    def _inc_actions(self) -> None:
        self.active_actions += 1
        if self.active_actions == 1:
            self._press_modifiers_if_needed()

    def _dec_actions(self) -> None:
        self.active_actions = max(0, self.active_actions - 1)
        if self.active_actions == 0:
            self._release_modifiers_if_idle()

    # ------------------------------ HUD TAGS ----------------------------------
    def _show_hud(self, tag: str, text: str) -> None:
        if tag in self._hud:
            try:
                for child in self._hud[tag].winfo_children():
                    if isinstance(child, tk.Label):
                        child.configure(text=text)
            except Exception:
                pass
            return
        win = tk.Toplevel(self.root)
        win.overrideredirect(True)
        try:
            win.attributes("-topmost", True)
            win.attributes("-alpha", 0.85)
        except Exception:
            pass
        theme = THEMES.get(self.theme_var.get(), THEMES["normal"])
        pad = tk.Frame(win, bd=0, bg=theme["panel"], highlightthickness=1, highlightbackground=theme["accent"])
        pad.pack()
        tk.Label(pad, text=text, font=("Segoe UI", 9, "bold"), bg=theme["panel"]).pack(padx=6, pady=3)
        self._hud[tag] = win
        self._update_hud_positions()

    def _hide_hud(self, tag: str) -> None:
        win = self._hud.pop(tag, None)
        if win:
            try: win.destroy()
            except Exception: pass
        if not self._hud and self._hud_job:
            try: self.root.after_cancel(self._hud_job)
            except Exception: pass
            self._hud_job = None

    def _update_hud_positions(self) -> None:
        if not self._hud:
            return
        px, py = self.root.winfo_pointerx(), self.root.winfo_pointery()
        for i, (tag, win) in enumerate(self._hud.items()):
            x = px + 16
            y = py + 16 + (i * 22)
            sw, sh = self.root.winfo_screenwidth(), self.root.winfo_screenheight()
            win.update_idletasks()
            ww, wh = win.winfo_reqwidth(), win.winfo_reqheight()
            x = min(max(0, x), sw - ww - 2)
            y = min(max(0, y), sh - wh - 2)
            try: win.geometry(f"+{int(x)}+{int(y)}")
            except Exception: pass
        self._hud_job = self.root.after(120, self._update_hud_positions)

    # ------------------------------ AUTO CLICKER ------------------------------
    def toggle_autoclick(self) -> None:
        if self.autoclick_running.is_set(): self._stop_autoclick()
        else: self._start_autoclick()

    def _start_autoclick(self) -> None:
        try: cps = max(1, int(self.cps_var.get()))
        except Exception: cps = 10; self.cps_var.set(10)
        self._persist_pref("cps", cps)
        interval = 1.0 / cps
        btn = self.MOUSE_BUTTONS.get(self.ac_button_var.get(), pmouse.Button.left)
        if self.autoclick_thread and self.autoclick_thread.is_alive():
            return
        self.autoclick_running.set(); self.session_clicks = 0
        self.ac_toggle_btn.configure(text="Stop")
        self._inc_actions()
        self._show_hud("auto_click", "Auto Clicker")

        def run():
            next_at = time.time()
            while self.autoclick_running.is_set():
                try:
                    self._press_modifiers_if_needed(); self.mctl.click(btn)
                    self.session_clicks += 1; self.stats.total_clicks += 1
                    if self.session_clicks % 10 == 0: self.stats.save()
                except Exception: pass
                next_at += interval
                time.sleep(max(0.0, next_at - time.time()))
            self.stats.save()

        self.autoclick_thread = threading.Thread(target=run, daemon=True)
        self.autoclick_thread.start()

    def _stop_autoclick(self) -> None:
        self.autoclick_running.clear(); self.ac_toggle_btn.configure(text="Start"); self._dec_actions()
        self._hide_hud("auto_click")

    # -------------------------------- HOLD CLICK ------------------------------
    def toggle_mouse_hold(self) -> None:
        if self.mouse_hold_running.is_set(): self._stop_mouse_hold()
        else: self._start_mouse_hold()

    def _start_mouse_hold(self) -> None:
        if self.mouse_hold_thread and self.mouse_hold_thread.is_alive():
            return
        btn = self.MOUSE_BUTTONS.get(self.hc_button_var.get(), pmouse.Button.left)
        self._persist_pref("hc_button", self.hc_button_var.get())
        self.mouse_hold_running.set(); self.hc_toggle_btn.configure(text="Release")
        self.hold_start_time = time.time(); self._inc_actions()
        self._show_hud("hold_click", "Click Hold")

        def run():
            try:
                self._press_modifiers_if_needed(); self.mctl.press(btn)
            except Exception: pass
            try:
                while self.mouse_hold_running.is_set(): time.sleep(0.05)
            finally:
                try: self.mctl.release(btn)
                except Exception: pass
                self._update_longest_hold(); self.hold_start_time = None

        self.mouse_hold_thread = threading.Thread(target=run, daemon=True)
        self.mouse_hold_thread.start()

    def _stop_mouse_hold(self) -> None:
        self.mouse_hold_running.clear(); self.hc_toggle_btn.configure(text="Hold"); self._dec_actions()
        self._hide_hud("hold_click")

    # -------------------------------- AUTO TYPER ------------------------------
    def toggle_typer(self) -> None:
        if self.typer_running.is_set(): self._stop_typer()
        else: self._start_typer()

    def _start_typer(self) -> None:
        if self.typer_thread and self.typer_thread.is_alive():
            return
        try:
            delay = float(self.typer_delay.get())
        except Exception:
            delay = 1.0; self.typer_delay.set(1.0)
        text = self.typer_text.get()
        if not text:
            self._alert(APP_NAME, "Type text cannot be empty."); return
        self._persist_pref("typer_delay", delay)
        self._persist_pref("typer_text", text)
        self._persist_pref("typer_enter", bool(self.typer_enter_var.get()))
        self.typer_running.set(); self.typer_toggle_btn.configure(text="Stop"); self._inc_actions()
        self._show_hud("typing", "Typing")

        def run():
            while self.typer_running.is_set():
                try:
                    self._press_modifiers_if_needed()
                    self.kctl.type(text)
                    if self.typer_enter_var.get():
                        self.kctl.press(SPECIAL_KEY_NAMES["enter"]); self.kctl.release(SPECIAL_KEY_NAMES["enter"])
                except Exception: pass
                time.sleep(max(0.01, delay))

        self.typer_thread = threading.Thread(target=run, daemon=True); self.typer_thread.start()

    def _stop_typer(self) -> None:
        self.typer_running.clear(); self.typer_toggle_btn.configure(text="Start"); self._dec_actions()
        self._hide_hud("typing")

    # ------------------------------- UTILITIES --------------------------------
    def _persist_pref(self, key: str, value) -> None:
        try:
            if self.stats.prefs is None:
                self.stats.prefs = {}
            self.stats.prefs[key] = value
            self.stats.save()
        except Exception:
            pass

    def _persist_mod(self, key: str, enabled: bool) -> None:
        try:
            mods = self.stats.prefs.get("mods", {})
            mods[key] = bool(enabled)
            self.stats.prefs["mods"] = mods
            self.stats.save()
        except Exception:
            pass

    def _update_longest_hold(self) -> None:
        if self.hold_start_time is None: return
        elapsed = max(0.0, time.time() - self.hold_start_time)
        if elapsed > self.stats.longest_hold_seconds:
            self.stats.longest_hold_seconds = elapsed; self.stats.save()

    # Clear buttons
    def _clear_total_clicks(self) -> None:
        self.stats.total_clicks = 0
        self.stats.save()
        self.total_clicks_var.set("Total clicks: 0")

    def _clear_longest_hold(self) -> None:
        self.stats.longest_hold_seconds = 0.0
        self.stats.save()
        self.longest_hold_var.set("Longest hold: 0.0s")

    def _alert(self, title: str, message: str) -> None:
        win = tk.Toplevel(self.root); win.title(title); win.transient(self.root); win.grab_set()
        frm = tk.Frame(win); frm.pack(fill=tk.BOTH, expand=True, padx=14, pady=12)
        tk.Label(frm, text=message, justify=tk.LEFT, wraplength=360, font=self.text_font).pack(anchor="w")
        tk.Button(frm, text="OK", command=win.destroy).pack(pady=(10, 0))
        win.update_idletasks()
        x = self.root.winfo_rootx() + self.root.winfo_width()//2 - win.winfo_reqwidth()//2
        y = self.root.winfo_rooty() + self.root.winfo_height()//2 - win.winfo_reqheight()//2
        win.geometry(f"+{max(0,x)}+{max(0,y)}")
        self.root.wait_window(win)

    def copy_email_to_clipboard(self) -> None:
        try:
            self.root.clipboard_clear(); self.root.clipboard_append(CONTACT_EMAIL)
            self._alert(APP_NAME, "Copied email to clipboard:\n" + CONTACT_EMAIL)
        except Exception:
            pass

    def open_email_app(self) -> None:
        subject = "Hey Teddy! ..."
        url = f"mailto:{CONTACT_EMAIL}?subject={quote(subject)}"
        try:
            webbrowser.open(url, new=1)
        except Exception:
            self._alert(APP_NAME, "Couldn't open email app; copying email instead.")
            self.copy_email_to_clipboard()

    def panic_stop(self) -> None:
        self.autoclick_running.clear(); self.mouse_hold_running.clear(); self.typer_running.clear()
        try:
            self.ac_toggle_btn.configure(text="Start"); self.hc_toggle_btn.configure(text="Hold"); self.typer_toggle_btn.configure(text="Start")
        except Exception: pass
        for tag in list(self._hud.keys()):
            self._hide_hud(tag)
        self._dec_actions(); self._release_modifiers_if_idle()

    def on_close(self) -> None:
        if self.use_tray_var.get() and getattr(self, "_tray_ready", False):
            self._save_window_geometry()
            # hide to tray by not destroying; reopen via tray 'Open'
            try: self.root.withdraw()
            except Exception: pass
            return
        self._really_quit()

    def _really_quit(self) -> None:
        try:
            if getattr(self, "_tray_icon", None):
                try: self._tray_icon.stop()
                except Exception: pass
        except Exception:
            pass
        self.panic_stop()
        try: self.klistener.stop()
        except Exception: pass
        self.stats.save()
        try: self.root.destroy()
        except Exception: pass

    def run(self) -> None:
        try:
            self.root.mainloop()
        except KeyboardInterrupt: self._really_quit()


if __name__ == "__main__":
    app = TeddyToolkit(); app.run()
